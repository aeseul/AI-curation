import type { Product } from '../types.ts';

export const GS25_PRODUCT_IMAGES = {
  buldak: '/assets/products/buldak.jpg',
  yukgaejang: '/assets/products/yukgaejang.jpg',
  samgakTuna: '/assets/products/samgak_tuna.jpg',
  samgakBibim: '/assets/products/samgak_bibim.jpg',
  stringCheese: '/assets/products/string_cheese.jpg',
  smokedEgg: '/assets/products/smoked_egg.jpg',
  bananaMilk: '/assets/products/banana_milk.jpg',
  water500ml: '/assets/products/water_500ml.jpg',
  chocobar: '/assets/products/chocobar.jpg',
  chickenBreast: '/assets/products/chicken_breast.jpg',
  // Category fallbacks (also mapped to real convenience store product photos)
  ramenCup: '/assets/products/buldak.jpg',
  kimbapRice: '/assets/products/samgak_tuna.jpg',
  dairyEgg: '/assets/products/string_cheese.jpg',
  chickenSausage: '/assets/products/chicken_breast.jpg',
  tteokDrink: '/assets/products/banana_milk.jpg',
} as const;

export function getProductImageUrl(
  product: Pick<Product, 'productId' | 'category' | 'name' | 'imageUrl'>,
): string {
  const name = product.name || '';

  if (name.includes('불닭')) {
    return GS25_PRODUCT_IMAGES.buldak;
  }
  if (name.includes('육개장') || name.includes('우동') || name.includes('라면')) {
    return GS25_PRODUCT_IMAGES.yukgaejang;
  }
  if (name.includes('참치마요')) {
    return GS25_PRODUCT_IMAGES.samgakTuna;
  }
  if (name.includes('전주비빔') || name.includes('김밥') || name.includes('볶음밥') || name.includes('컵반')) {
    return GS25_PRODUCT_IMAGES.samgakBibim;
  }
  if (name.includes('스트링치즈') || name.includes('치즈') || name.includes('요거트')) {
    return GS25_PRODUCT_IMAGES.stringCheese;
  }
  if (name.includes('훈제란') || name.includes('반숙란') || name.includes('계란')) {
    return GS25_PRODUCT_IMAGES.smokedEgg;
  }
  if (name.includes('바나나')) {
    return GS25_PRODUCT_IMAGES.bananaMilk;
  }
  if (name.includes('생수') || name.includes('탄산수') || name.includes('꿀물')) {
    return GS25_PRODUCT_IMAGES.water500ml;
  }
  if (name.includes('초코바') || name.includes('초코') || name.includes('빵') || name.includes('샌드') || name.includes('스낵')) {
    return GS25_PRODUCT_IMAGES.chocobar;
  }
  if (name.includes('닭가슴살') || name.includes('소시지') || name.includes('후랑크') || name.includes('오징어')) {
    return GS25_PRODUCT_IMAGES.chickenBreast;
  }

  if (product.imageUrl) {
    return product.imageUrl;
  }

  if (product.category === '면류') {
    return GS25_PRODUCT_IMAGES.ramenCup;
  }
  if (product.category === '김밥/도시락') {
    return GS25_PRODUCT_IMAGES.kimbapRice;
  }
  if (product.category === '유제품/치즈' || product.category === '계란/간편식') {
    return GS25_PRODUCT_IMAGES.dairyEgg;
  }
  if (product.category === '육가공/안주') {
    return GS25_PRODUCT_IMAGES.chickenSausage;
  }
  if (product.category === '음료') {
    return GS25_PRODUCT_IMAGES.bananaMilk;
  }

  return GS25_PRODUCT_IMAGES.chocobar;
}
