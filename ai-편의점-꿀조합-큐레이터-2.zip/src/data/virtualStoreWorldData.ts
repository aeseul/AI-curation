export type StoreZoneId =
  | 'entrance'
  | 'ramen'
  | 'fridge'
  | 'dairy'
  | 'promo'
  | 'snacks'
  | 'microwave'
  | 'checkout'
  | 'basket';

export interface StoreZoneMeta {
  id: StoreZoneId;
  title: string;
  shortLabel: string;
  subtitle: string;
  ariaLabel: string;
  accentColor: string;
  characterTarget: { x: number; y: number };
  productIds: string[];
}

export const VIRTUAL_STORE_ZONES: Record<StoreZoneId, StoreZoneMeta> = {
  entrance: {
    id: 'entrance',
    title: 'GS25 입구 · 자동문',
    shortLabel: '입구',
    subtitle: '선택한 매장 정보와 가상 체험 안내를 확인하거나 입구로 나갈 수 있어요.',
    ariaLabel: '입구와 자동문 열기',
    accentColor: '#319447',
    characterTarget: { x: 245, y: 392 },
    productIds: [],
  },
  fridge: {
    id: 'fridge',
    title: '음료 냉장고',
    shortLabel: '냉장고',
    subtitle: '시원한 바나나우유(1+1 행사)와 생수, 치즈를 바로 꺼내보세요.',
    ariaLabel: '음료 냉장고 열기',
    accentColor: '#007CFF',
    characterTarget: { x: 300, y: 215 },
    productIds: ['P007', 'P008', 'P005'],
  },
  dairy: {
    id: 'dairy',
    title: '냉장식품 · 유제품 코너',
    shortLabel: '유제품/계란',
    subtitle: '스트링치즈, 훈제란 등 간편하게 곁들이기 좋은 냉장 식품 코너입니다.',
    ariaLabel: '냉장식품 및 유제품 코너 열기',
    accentColor: '#319447',
    characterTarget: { x: 438, y: 185 },
    productIds: ['P005', 'P006', 'P007'],
  },
  promo: {
    id: 'promo',
    title: '1+1 · 2+1 행사 코너',
    shortLabel: '행사 코너',
    subtitle: '가상 1+1 바나나우유와 2+1 초코바 혜택을 한눈에 확인해 보세요.',
    ariaLabel: '행사 상품 코너 열기',
    accentColor: '#F49A24',
    characterTarget: { x: 585, y: 222 },
    productIds: ['P007', 'P009'],
  },
  ramen: {
    id: 'ramen',
    title: '라면 · 간편식 진열대',
    shortLabel: '라면/간편식',
    subtitle: '불닭볶음면, 육개장 사발면, 삼각김밥까지 인기 한 끼 조합이 모여 있어요.',
    ariaLabel: '라면 및 간편식 진열대 열기',
    accentColor: '#E85D2C',
    characterTarget: { x: 255, y: 295 },
    productIds: ['P001', 'P002', 'P003', 'P004'],
  },
  snacks: {
    id: 'snacks',
    title: '중앙 진열대 (스낵 · 간편식)',
    shortLabel: '중앙 진열대',
    subtitle: '초코바(2+1)와 가볍게 곁들이는 간식·삼각김밥 코너입니다.',
    ariaLabel: '중앙 스낵 진열대 열기',
    accentColor: '#D98218',
    characterTarget: { x: 455, y: 286 },
    productIds: ['P009', 'P003', 'P004', 'P006'],
  },
  microwave: {
    id: 'microwave',
    title: '전자레인지 · 온수기 코너',
    shortLabel: '조리 코너',
    subtitle: '전자레인지·온수 조리가 가능한 상품과 안전 안내를 확인하세요.',
    ariaLabel: '전자레인지 및 온수기 조리 안내 열기',
    accentColor: '#F49A24',
    characterTarget: { x: 642, y: 292 },
    productIds: ['P001', 'P002', 'P003', 'P004', 'P005'],
  },
  checkout: {
    id: 'checkout',
    title: '계산대 · 예산 정산',
    shortLabel: '계산대',
    subtitle: '담은 상품의 행사 할인과 남은 예산을 계산하고 가상 구매를 완료해요.',
    ariaLabel: '계산대 장바구니 및 예산 계산 열기',
    accentColor: '#319447',
    characterTarget: { x: 605, y: 382 },
    productIds: [],
  },
  basket: {
    id: 'basket',
    title: '내 쇼핑 바구니',
    shortLabel: '바구니',
    subtitle: '지금까지 바구니에 담은 상품 수량과 금액을 빠르게 확인합니다.',
    ariaLabel: '쇼핑 바구니 요약 열기',
    accentColor: '#252525',
    characterTarget: { x: 495, y: 405 },
    productIds: [],
  },
};

export const STORE_ZONE_ORDER: StoreZoneId[] = [
  'ramen',
  'fridge',
  'dairy',
  'promo',
  'snacks',
  'microwave',
  'checkout',
  'basket',
  'entrance',
];

export const CHARACTER_GUIDE_TIPS: string[] = [
  '라면 코너를 눌러 불닭볶음면과 삼각김밥을 살펴보세요!',
  '노란색 행사 코너에서 1+1 바나나우유와 2+1 초코바를 확인해 보세요.',
  '5,000원 예산 게이지를 보면서 나만의 꿀조합을 완성해 보세요!',
  '상품을 고른 뒤 오른쪽 아래 계산대를 누르면 가상 영수증을 받을 수 있어요.',
];

export const WORLD_TUTORIAL_STEPS = [
  {
    step: 1,
    title: '진열대를 클릭해 상품을 살펴보세요.',
    description: '라면 코너, 음료 냉장고, 행사 코너 등 원하는 가구를 눌러보세요.',
  },
  {
    step: 2,
    title: '상품을 장바구니에 담아보세요.',
    description: '1+1·2+1 행사 할인과 가상 재고 수량이 바로 반영됩니다.',
  },
  {
    step: 3,
    title: '5,000원 안에서 한 끼를 완성해보세요.',
    description: '계산대에서 가상 구매를 완료하거나 맞춤 꿀조합 추천을 받아보세요.',
  },
];
